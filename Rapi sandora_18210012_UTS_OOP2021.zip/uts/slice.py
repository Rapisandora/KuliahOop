data = [1,2,'tiga','empat',5]
print (data)
data_baru = data [0:3]
print (data_baru)