a = "hutan"
if a == "hutan":
    print ("kota harus dibangun")
else:
    print ("hutan dan kota harus dibangun")
b = "kota"
if b == "hutan":
    print ("kota harus dibangun")
elif b=="hutan":
    print ("hutan harus dijaga")
else :
    print ("hutan dan kota harus dibangun")