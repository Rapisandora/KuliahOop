num = [1,2,3,4,5]
for a in num:
    print ("saya akan lulus tepat waktu")